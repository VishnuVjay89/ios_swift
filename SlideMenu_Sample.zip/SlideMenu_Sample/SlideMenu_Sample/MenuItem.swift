//
//  MenuItem.swift
//  SlideMenu_Sample
//
//  Created by Vishnu on 08/02/17.
//  Copyright © 2017 Vishnu. All rights reserved.
//

import UIKit

/// Defines Enum type for representing item type in menu
enum ItemType :String {
    case
        profile = "PROFILE",
        menu    = "MENU",
        unknown = "UNKNOWN"
}

/// Model class for menu item
class MenuItem {
    
    /// Represents id for each item
    var id                        = ""
    /// Image for menu icon or profile image
    var iconImage                 :UIImage?
    /// Represents background image for each item
    var backgroundImage           :UIImage?
    /// Represents title for each item
    var title                     = ""
    /// Type represents the menu item type
    var type:ItemType             = .unknown
    
    // MARK: Custom Initialisers

    init(itemId id:String,menuTitle title:String,itemType type:ItemType,background image:UIImage?,iconImage icon:UIImage?) {
        
        self.backgroundImage = image
        self.id              = id
        self.title           = title
        self.type            = type
        self.iconImage       = icon
        
    }
}
