//
//  ViewController.swift
//  SlideMenu_Sample
//
//  Created by Vishnu on 08/02/17.
//  Copyright © 2017 Vishnu. All rights reserved.
//

import UIKit

class ViewController: UIViewController,MenuListDataSource,MenulistDelegate {
       var dictArray = [["id":"1","title":"Home","typeOfMenu":ItemType.profile,"backgroundImage":#imageLiteral(resourceName: "swift"),"menuIcon":#imageLiteral(resourceName: "Apple")],["id":"2","title":"About","typeOfMenu":ItemType.menu,"backgroundImage":#imageLiteral(resourceName: "swift"),"menuIcon":#imageLiteral(resourceName: "swift")],["id":"3","title":"Call","typeOfMenu":ItemType.menu,"backgroundImage":#imageLiteral(resourceName: "swift"),"menuIcon":#imageLiteral(resourceName: "Apple")]]
    
    
    var menu:MenuItem?
    var menuItems = [MenuItem]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    func makeModel(){
        for item in dictArray {
                    menu = MenuItem(itemId: item["id"] as! String, menuTitle: item["title"] as! String, itemType: item["typeOfMenu"] as! ItemType, background: item["backgroundImage"] as! UIImage?, iconImage: item["menuIcon"] as! UIImage?)
                    menuItems.append(menu!)
            }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnShowMenu(_ sender: Any) {
        makeModel()
        let pvc = storyboard?.instantiateViewController(withIdentifier: "SlideMenu") as! MenuController
        pvc.dataSource = self
        pvc.delegate   = self
        self.present(pvc, animated: true, completion: nil)
    }
    
    func getData() -> [MenuItem] {
        return menuItems
    }
    func didSelect(item: MenuItem, atIndex index: Int) {
        debugPrint("Id \(item.id) selected")
    }

}

