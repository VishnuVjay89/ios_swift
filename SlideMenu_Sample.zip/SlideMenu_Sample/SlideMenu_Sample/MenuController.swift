////
////  MenuViewController.swift
////  SlideMenu_Sample
////
////  Created by Vishnu on 08/02/17.
////  Copyright © 2017 Vishnu. All rights reserved.
////
//
import UIKit

/// DataSource for Menu Item
protocol MenuListDataSource {
    
    /// Data source for preparing the Menu
    /// The data items should contains keys Title, image (iconImage) or imageURL (url for image)
    /// - Returns: Array of dictionary that contains the data for list view
   func getData() -> [MenuItem]
}
/// Delegate for menu Item
protocol MenulistDelegate {
    
    /// Tells the delegate that the user has selected an item at the given index
    ///
    /// - Parameters:
    ///   - item: Selected list item
    ///   - index: Index of the selected item
    func didSelect(item:MenuItem, atIndex index:Int)
}

class MenuController: UITableViewController{
    
    /// Defines the datasource
    var dataSource :MenuListDataSource?
    /// Defines the delegates
    var delegate:MenulistDelegate?
    /// Creates object for array of MenuItems
    fileprivate var menuItemList:[MenuItem] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        guard let menuItems = dataSource?.getData() else {
            return
        }
        menuItemList = menuItems
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }


    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return menuItemList.count
    }
 
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        // Configure the cell...
        var retCell : UITableViewCell
        
        if menuItemList[indexPath.row].type == .profile {
            let cell1: MenuProfileTableViewCell = tableView.dequeueReusableCell(withIdentifier: "Cell1") as! MenuProfileTableViewCell
            cell1.imgProfileBackgroundVw.image = menuItemList[indexPath.row].backgroundImage
            cell1.imgProfileImageVw.image      = menuItemList[indexPath.row].iconImage
            retCell = cell1
            
        }else {
            let cell2: MenuTableViewCell = tableView.dequeueReusableCell(withIdentifier: "Cell2") as! MenuTableViewCell
            cell2.lblMenuTitle.text = menuItemList[indexPath.row].title
            cell2.imgMenuIcon.image = menuItemList[indexPath.row].iconImage
            retCell = cell2
        }
        return retCell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedItem = menuItemList[indexPath.row]
        delegate?.didSelect(item: selectedItem, atIndex: indexPath.row)
    }
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if menuItemList[indexPath.row].type == .profile{
            return 160
        }else{
            return UITableViewAutomaticDimension
        }
        
    }

 
}
