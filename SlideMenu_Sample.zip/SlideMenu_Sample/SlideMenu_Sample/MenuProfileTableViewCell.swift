//
//  MenuProfileTableViewCell.swift
//  SlideMenu_Sample
//
//  Created by Vishnu on 08/02/17.
//  Copyright © 2017 Vishnu. All rights reserved.
//

import UIKit

class MenuProfileTableViewCell: UITableViewCell {

    @IBOutlet weak var imgProfileBackgroundVw: UIImageView!
    @IBOutlet weak var imgProfileImageVw: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
